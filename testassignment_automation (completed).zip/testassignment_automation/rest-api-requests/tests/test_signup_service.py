import pytest
from conftest import get_latest_user_data_from_database,get_user_data_from_database
from conftest import parse_validation_schema


class TestSignupService:
    
    @pytest.mark.allure("Test Signup Functionality")
    def test_signup(self, signup_page):
        self.user_token, self.user_name = signup_page.signup()
        assert self.user_token is not None
        assert self.user_name is not None
        print("User Name:", self.user_name)
        print("User Token:", self.user_token)
        # Retrieve user data from the database
        database_data =  get_latest_user_data_from_database()
        assert (self.user_name,self.user_token) in [(record[1],record[3]) for record in database_data] 
        print(database_data)

   
    @pytest.mark.allure("Test Token Renewal Functionality")
    def test_renew_token(self, signup_page):
        renewed_token = signup_page.renew_token()
        assert renewed_token is not None
        print("Renewed Token:", renewed_token)
        # Retrieve user data from the database
        database_data =get_latest_user_data_from_database ()
        # Perform assertions to compare database data with the renewed token 
        assert renewed_token in [record[3] for record in database_data ]
        print(database_data)
       
    
    @pytest.mark.allure("Test Token Validation Functionality")
    def test_validate_token(self, signup_page):
        validation_status = signup_page.validate_token()
        assert validation_status == True
        print("Validation Status:", validation_status)
       
    
    @pytest.mark.allure("Test Get User Data Functionality")
    def test_get_user(self, signup_page):
        user = signup_page.get_user()
        expected_user = signup_page.user_name
        assert user == expected_user
        f"Actual User: {user} is not equal to expected User: {expected_user}"
        print("Actual User:", user)
        # Retrieve user data from database
        database_data = get_user_data_from_database()
        assert user in database_data  
        
    
    @pytest.mark.allure("Test Get Quote Functionality")
    def test_get_quote(self, signup_page):
        response = signup_page.get_quote()  
        assert response is not None
        assert response.status_code == 200
        print("Actual Quote Response:", response.json())
        if response.status_code == 422:
            validation_schema = parse_validation_schema(response)
            for error in validation_schema.details:
                print(f"Location: {error.loc}, Message: {error.msg}, Type: {error.type}")
       
    
    @pytest.mark.allure("Test Get Weather Data Functionality")
    def test_get_weather(self, signup_page):
       response = signup_page.get_weather()
       assert response is not None
       assert response.status_code == 200
       print("Actual Weather Response:", response.json())
       if response.status_code == 422:
            validation_schema = parse_validation_schema(response)
            for error in validation_schema.details:
                print(f"Location: {error.loc}, Message: {error.msg}, Type: {error.type}")
       