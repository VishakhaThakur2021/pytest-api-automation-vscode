class Endpoints:
    SIGNUP_URL = "http://127.0.0.1:8081/api/v1/signupsrv"
    QUOTE_URL = "http://127.0.0.1:8081/api/v1/quotesrv"
    WEATHER_URL = "http://127.0.0.1:8081/api/v1/weathersrv"