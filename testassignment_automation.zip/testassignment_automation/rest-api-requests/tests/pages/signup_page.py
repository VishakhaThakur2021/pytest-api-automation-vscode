import re
import requests
from endpoints.endpoints import Endpoints
from faker import Faker
# Create a new instance of Faker
faker = Faker()


class SignupPage:
    def __init__(self):
        self.user_name = None
        self.user_token = None
        pass

    
    def signup(self):
        if not self.user_name or not self.user_token:
         url = f"{Endpoints.SIGNUP_URL}/signup"
        name = faker.word()
        passwd = faker.password()
        params = {"name": name, "passwd": passwd}
        response = requests.post(url, params=params)
        self.user_name = name
        self.user_token = self.extract_token(response.text)
        print(response.url)
        return self.user_token,self.user_name
        
    
        
    def extract_token(self, response_text):
        token_pattern = re.compile(r"token: ([a-f0-9]+)")
        match = token_pattern.search(response_text)
        if match:
            return match.group(1)
        return None

    
    def renew_token(self):
        url = f"{Endpoints.SIGNUP_URL}/renew"
        params = {"name": self.user_name}
        headers = {"Authorization": f"Bearer {self.user_token}"}
        response = requests.patch(url, params=params, headers=headers)
        self.user_token = self.extract_token(response.text)
        print(response.url)
        return  self.user_token
        
    
    def validate_token(self):
        url = f"{Endpoints.SIGNUP_URL}/validate"
        params = {"token": self.user_token}
        response = requests.get(url, params=params)
        print(response.url)
        return response.status_code ==200
    
    
    def get_user(self):
        url = f"{Endpoints.SIGNUP_URL}/user"
        params = {"token": self.user_token}
        response = requests.get(url, params=params)
        print(response.url)
        return response.json()
    
    
    def get_quote(self):
        url = f"{Endpoints.QUOTE_URL}/quote"
        params = {"token": self.user_token}
        response = requests.get(url, params=params)
        print(response.url)
        return response
    
    
    def get_weather(self):
        url = f"{Endpoints.WEATHER_URL}/weather"
        params = {"token": self.user_token}
        response = requests.get(url, params=params)
        print(response.url)
        return response