import pytest
import sqlite3
import json
from pages.signup_page import SignupPage

class ValidationError:
    def __init__(self, loc, msg, type):
        self.loc = loc
        self.msg = msg
        self.type = type

class ValidationSchema:
    def __init__(self, details):
        self.details = details

def parse_validation_schema(response):
    try:
        schema = response.json()
        details = []
        for detail in schema["detail"]:
            loc = detail.get("loc", "")
            msg = detail.get("msg", "")
            type = detail.get("type", "")
            error = ValidationError(loc=loc, msg=msg, type=type)
            details.append(error)
        return ValidationSchema(details=details)
    except json.JSONDecodeError:
        print("Error decoding JSON response")
        return None
    except KeyError:
        print("Invalid JSON schema format")
        return None        


@pytest.fixture(scope="class")
def signup_page():
    signup_page_instance = SignupPage()
    yield signup_page_instance


# Function to retrieve user data from SQLite database
def get_user_data_from_database():
    conn = sqlite3.connect('signup_service/be_db.db')
    cursor = conn.cursor()
    userdata = cursor.execute('SELECT * FROM user;')
    data = userdata.fetchall()
    conn.close()
    return data


# Function to retrieve the latest user data from SQLite database
def get_latest_user_data_from_database():
    conn = sqlite3.connect('signup_service/be_db.db')
    cursor = conn.cursor()
    latestdata = cursor.execute('SELECT * FROM user ORDER BY id DESC')  
    data = latestdata.fetchall()
    conn.close()
    return data


# Fixture to provide database access
@pytest.fixture(scope="session")
def database_access():
    return {
        'get_user_data_from_database': get_user_data_from_database,
        'get_latest_user_data_from_database': get_latest_user_data_from_database
    }

